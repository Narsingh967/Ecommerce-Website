const topCategoriesdata = [
    {
      cover: "./assets/top-categories/category-1.png",
      para: "Headphones",
      desc: "3k orders this week",
    },
    {
      cover: "./assets/top-categories/category-2.png",
      para: "Watches",
      desc: "4k orders this week",
    },
    {
      cover: "./assets/top-categories/category-3.png",
      para: "Sunglasses",
      desc: "6k orders this week",
    },
    {
      cover: "./assets/top-categories/category-2.png",
      para: "Watches",
      desc: "4k orders this week",
    },
    {
      cover: "./assets/top-categories/category-3.png",
      para: "Sunglasses",
      desc: "6k orders this week",
    },
  ]
  
  export default topCategoriesdata