import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Cart.css";

const Cart = ({
  cartItems,
  addToCart,
  deleteFromCart,
  removeFromCart,
  clearCart,
}) => {
  const [isCheckout, setIsCheckout] = useState(false);
  const [isOrderPlaced, setIsOrderPlaced] = useState(false);
  const [address, setAddress] = useState({
    name: "",
    street: "",
    city: "",
    zip: "",
    country: "",
  });

  const navigate = useNavigate();

  const totalPrice = cartItems.reduce(
    (price, item) => price + item.qty * item.price,
    0
  );

  const handleCheckoutClick = () => {
    setIsCheckout(true);
  };

  const handleOrderPlace = () => {
    setIsOrderPlaced(true); // Placeholder for order placement
  };

  const handleAddressChange = (e) => {
    setAddress({ ...address, [e.target.name]: e.target.value });
  };

  const handleContinueShopping = () => {
    clearCart(); // Clear the cart
    navigate("/"); // Redirect to homepage
  };

  return (
    <>
      <section className="cart-items">
        {/* Cart display when items are present */}
        {!isCheckout && !isOrderPlaced && (
          <div className="container cart-flex">
            <div className="cart-details">
              {cartItems.length === 0 && (
                <h1 className="no-items product">
                  There are no items in the cart.
                </h1>
              )}
              {cartItems.map((item) => {
                const productQty = item.price * item.qty;
                return (
                  <div
                    className="cart-list product d_flex cart-responsive"
                    key={item.id}
                  >
                    <div className="img">
                      <img
                        src={item.img}
                        alt="Picture of this item is unavailable"
                      />
                    </div>
                    <div className="cart-details">
                      <h3>{item.name}</h3>
                      <h4>
                        Rs{item.price} x {item.qty} = Rs{productQty}.00
                      </h4>
                    </div>
                    <div className="cart-items-function">
                      <div className="cartControl d_flex">
                        <button
                          className="cart-button increase"
                          onClick={() => addToCart(item)}
                        >
                          +
                        </button>
                        <span className="item-quantity">{item.qty}</span>
                        <button
                          className="cart-button decrease"
                          onClick={() => deleteFromCart(item)}
                        >
                          -
                        </button>
                      </div>
                      <button
                        className="remove-item-button"
                        onClick={() => removeFromCart(item)}
                      >
                        Remove Item
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="cart-total product-cart">
              <h2>Cart Summary</h2>
              <div className="d_flex">
                <h4>Total Price:</h4>
                <h3>Rs{totalPrice}.00</h3>
              </div>
              <button className="checkout" onClick={handleCheckoutClick}>
                Checkout Now!
              </button>
            </div>
          </div>
        )}

        {/* Address Form */}
        {isCheckout && !isOrderPlaced && (
          <div className="address-form">
            <h2>Shipping Address</h2>
            <form>
              <label>
                Name:
                <input
                  type="text"
                  name="name"
                  value={address.name}
                  onChange={handleAddressChange}
                  required
                />
              </label>
              <label>
                Street:
                <input
                  type="text"
                  name="street"
                  value={address.street}
                  onChange={handleAddressChange}
                  required
                />
              </label>
              <label>
                City:
                <input
                  type="text"
                  name="city"
                  value={address.city}
                  onChange={handleAddressChange}
                  required
                />
              </label>
              <label>
                ZIP Code:
                <input
                  type="Number"
                  name="zip"
                  value={address.zip}
                  onChange={handleAddressChange}
                  required
                />
              </label>
              <label>
                Country:
                <input
                  type="text"
                  name="country"
                  value={address.country}
                  onChange={handleAddressChange}
                  required
                />
              </label>
              <button
                type="button"
                className="order-button"
                onClick={handleOrderPlace}
              >
                Place Order
              </button>
            </form>
          </div>
        )}

        {/* Order Placed Confirmation */}
        {isOrderPlaced && (
          <div className="order-success">
            <h2>Order Placed Successfully!</h2>
            <p>Thank you for your purchase. Your order is on its way!</p>
            <button className="continue-shopping" onClick={handleContinueShopping}>
              Continue Shopping
            </button>
          </div>
        )}
      </section>
    </>
  );
};

export default Cart;
