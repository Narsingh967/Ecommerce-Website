const shoppingData = [
  {
    id: 1,
    title: "15% Off On Your First Shopping",
    desc: "Limited Time Offer – Grab it Before It's Gone!",
    cover: "./assets/main-slider/slide-4.png",
  },
  {
    id: 2,
    title: "15% Off On Your First Shopping",
    desc: "Why Pay More When You Can Save More?",
    cover: "./assets/main-slider/slide-3.png",
  },
  {
    id: 3,
    title: "15% Off On Your First Shopping",
    desc: "Shop More, Save More!",
    cover: "./assets/main-slider/slide-2.png",
  },
];
export default shoppingData;
