const categoryData = [
  {
    categoryImg: "./assets/category/category1.png",
    categoryName: "Fashion",
  },
  {
    categoryImg: "./assets/category/category2.png",
    categoryName: "Electronic",
  },
  {
    categoryImg: "./assets/category/category3.png",
    categoryName: "Cars",
  },
  {
    categoryImg: "./assets/category/category4.png",
    categoryName: "Garden",
  },
  {
    categoryImg: "./assets/category/category5.png",
    categoryName: "Gifts",
  },
  {
    categoryImg: "./assets/category/category6.png",
    categoryName: "Music",
  },
  {
    categoryImg: "./assets/category/category7.png",
    categoryName: "Health",
  },
  {
    categoryImg: "./assets/category/category8.png",
    categoryName: "Pets",
  },
  {
    categoryImg: "./assets/category/category9.png",
    categoryName: "Baby",
  },
  {
    categoryImg: "./assets/category/category10.png",
    categoryName: "Groceries",
  },
  {
    categoryImg: "./assets/category/category11.png",
    categoryName: "Books",
  },
];

export default categoryData;
