const discountData = [
    {
      cover: "./assets/discount/discount-1.png",
      name: "BenuX 2022",
      price: "Rs 25000",
    },
    {
      cover: "./assets/discount/discount-2.png",
      name: "Sony TV 1080p",
      price: "Rs 45000",
    },
    {
      cover: "./assets/discount/discount-3.png",
      name: "Sony PS4",
      price: "Rs 55999",
    },
    {
      cover: "./assets/discount/discount-4.png",
      name: "Setgearr 2022",
      price: "Rs 6999",
    },
    {
      cover: "./assets/discount/discount-5.png",
      name: "Tony BGB",
      price: "Rs 8999",
    },
    {
      cover: "./assets/discount/discount-6.png",
      name: "RG products",
      price: "Rs 4999",
    },
    {
      cover: "./assets/discount/discount-7.png",
      name: "Ranasonic 2022",
      price: "Rs 30999",
    },
    {
      cover: "./assets/discount/discount-8.png",
      name: "Pune HD",
      price: "Rs 2399",
    }
  ]
  export default discountData;