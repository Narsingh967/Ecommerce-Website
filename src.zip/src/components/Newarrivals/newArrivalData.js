const newArrivalData = [
    {
      cover: "./assets/new-arrivals/arrivals1.png",
      name: "Samsung Watch 6LTE",
      price: "16799",
    },
    {
      cover: "./assets/new-arrivals/arrivals2.png",
      name: "CMF Watch Pro 2",
      price: "4999",
    },
    {
      cover: "./assets/new-arrivals/arrivals3.png",
      name: "Apple Watch Series 9",
      price: "44990",
    },
    {
      cover: "./assets/new-arrivals/arrivals4.png",
      name: "Samsung Watch FE",
      price: "9999",
    },
    {
      cover: "./assets/new-arrivals/arrivals5.png",
      name: "Timex Smart iconnect",
      price: "999",
    },
    {
      cover: "./assets/new-arrivals/arrivals6.png",
      name: "Cult Ace X",
      price: "999",
    },
  ]
  
  export default newArrivalData;