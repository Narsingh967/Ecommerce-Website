const flashDealsData = {
  productItems: [
    {
      id: 1,
      discount: 15,
      img: "./assets/flash-deals/flash-1.png",
      name: "Iphone 16",
      price: 89900,
    },
    {
      id: 2,
      discount: 10,
      img: "./assets/flash-deals/flash-2.png",
      name: "Iphone 15 Pro",
      price: 113999 ,
    },
    {
      id: 3,
      discount: 10,
      img: "./assets/flash-deals/flash-3.png",
      name: "Iphone 14",
      price: 50999,
    },
    {
      id: 4,
      discount: 20,
      img: "./assets/flash-deals/flash-4.png",
      name: "Oneplus 11R",
      price: 34990,
    },
    {
      id: 5,
      discount: 20,
      img: "./assets/flash-deals/flash-5.png",
      name: "Oneplus 12",
      price: 59994,
    },
    {
      id: 6,
      discount: 30,
      img: "./assets/flash-deals/flash-6.png",
      name: "Realme 12 Pro",
      price: 24999,
    },

    {
      id: 7,
      discount: 10,
      img: "./assets/flash-deals/flash-7.png",
      name: "Samsung S24 Ultra",
      price: 129999,
    },
  ],
};

export default flashDealsData;
