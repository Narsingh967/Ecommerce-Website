import React, { useState } from "react";
import { Link } from "react-router-dom";
import Slider from "react-slick";

// Setting up arrows to display next and previous arrows
const NextArrow = (props) => {
  const { onClick } = props;
  return (
    <div className="control-btn" onClick={onClick}>
      <button aria-label="Next slide" className="next">
        <i className="fa fa-long-arrow-alt-right"></i>
      </button>
    </div>
  );
};

const PrevArrow = (props) => {
  const { onClick } = props;
  return (
    <div className="control-btn" onClick={onClick}>
      <button aria-label="Previous slide" className="prev">
        <i className="fa fa-long-arrow-alt-left"></i>
      </button>
    </div>
  );
};

const Flashcard = ({ productItems, addToCart }) => {
  const [count, setCount] = useState(0);
  const increment = () => {
    setCount(count + 1);
  };

  // Settings for the slick slider with auto-slide feature
  const settings = {
    dots: false,
    infinite: true,
    speed: 800,
    slidesToShow: 5,
    slidesToScroll: 1,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    autoplay: true, // Enables auto-sliding
    autoplaySpeed: 3000, // Interval between slides in milliseconds (3 seconds)
    responsive: [
      {
        breakpoint: 1440,
        settings: {
          slidesToShow: 4,
          dots: true, // Show dots on smaller screens
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          dots: true, // Show dots on smaller screens
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          dots: true, // Show dots on smaller screens
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          dots: true, // Show dots on even smaller screens
        },
      },
    ],
  };

  return (
    <>
      <style>{`
        .product {
          display: flex;
          flex-direction: column;
          height: 100%;
          border: 1px solid #ddd;
          box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
          background-color: white;
        }

        .product-details {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          flex-grow: 1;
        }

        .img {
          position: relative;
          overflow: hidden;
        }

        .product-like {
          position: absolute;
          top: 10px;
          right: 10px;
          background-color: rgba(255, 255, 255, 0.7);
          padding: 5px;
          border-radius: 50%;
        }

        .product-details h3 {
          font-size: 16px;
          font-weight: bold;
          margin: 10px 0;
        }

        .rate i {
          color: #ffcc00;
        }

        .price {
          margin-top: auto;
        }

        .price h4 {
          font-size: 18px;
          color: #ff6347;
        }

        .control-btn {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          z-index: 1;
        }

        .next, .prev {
          background-color: rgba(0, 0, 0, 0.5);
          color: white;
          border: none;
          padding: 10px;
          cursor: pointer;
        }

        .slick-slide {
          display: flex;
          justify-content: center;
        }

        .slick-dots {
          bottom: -30px;
        }

        /* Stylish Add to Cart button */
        .add-to-cart-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 12px 24px;  /* Increased padding for a bigger button */
          background-color: #ff6347;
          color: white;
          font-size: 18px;
          border: none;
          border-radius: 30px;
          cursor: pointer;
          transition: background-color 0.3s ease, transform 0.2s ease;
          width: 100%;  /* Ensures the button fills the available space */
          max-width: 180px; /* Sets max width to prevent the button from getting too large */
          box-sizing: border-box; /* Makes sure padding is considered in the total width */
        }

        .add-to-cart-btn:hover {
          background-color: #e55347; /* Darken on hover */
          transform: scale(1.05); /* Slightly enlarge button on hover */
        }

        .add-to-cart-btn img {
          width: 20px;  /* Set width for the cart image */
          height: auto; /* Maintain aspect ratio */
        }
      `}</style>

      {/* Slider */}
      <Slider {...settings}>
        {productItems.map((product, index) => {
          return (
            <div className="box" key={index}>
              <div className="product">
                <div className="img">
                  <span className="discount">{product.discount}% Off</span>
                  <img src={product.img} alt={product.name} />
                  <div className="product-like">
                    <label>{count}</label>
                    <br />
                    <i
                      className="fa-regular fa-heart"
                      onClick={increment}
                    ></i>
                  </div>
                </div>
                <div className="product-details">
                  <Link to={`/all-products/${product.id}`}>
                    <h3 className="truncate">{product.name}</h3>
                  </Link>
                  <div className="rate">
                    <i className="fa fa-star"></i>
                    <i className="fa fa-star"></i>
                    <i className="fa fa-star"></i>
                    <i className="fa fa-star"></i>
                    <i className="fa fa-star"></i>
                  </div>
                  <div className="price">
                    <h4>{product.price}.00</h4>
                    {/* Updated Add to Cart button with Cart image */}
                    <button
                      className="add-to-cart-btn"
                      onClick={() => addToCart(product)}  // Calls addToCart with the product data
                    >
                      <img
                        src="https://img.icons8.com/ios-filled/50/ffffff/shopping-cart.png" // Replace with your own image URL
                        alt="Add to Cart"
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </Slider>
    </>
  );
};

export default Flashcard;
